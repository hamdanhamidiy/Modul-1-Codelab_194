package modul4.codelab.kendaraan.util;

public interface ShootAble {
void Shoot(String vehicle);

}
