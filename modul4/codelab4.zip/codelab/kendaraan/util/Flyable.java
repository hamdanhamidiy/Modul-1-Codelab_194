package modul4.codelab.kendaraan.util;

public interface Flyable {
    public void fly();
}
